# Informal AnimeVsub Application!

> The goal of this application is to allow users to interact intuitively and explore new Anime sets in place of the outdated web interface of [animevsub](https://animevietsub.tv). 
> 
> And especially this app will **speed up the Anime viewer by 20 times**!! That means no more `downloading...`, enjoy the best quality Anime episodes and no `downloading...`

## Development
### To be on

- [ ] API system
- [ ] UI
