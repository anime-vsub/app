import { defineConfig } from 'windicss/helpers'
import lineClamp from 'windicss/plugin/line-clamp'

export default defineConfig({
  plugins: [lineClamp]
})