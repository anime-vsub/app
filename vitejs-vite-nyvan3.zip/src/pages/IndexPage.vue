<template>
  <q-header class="bg-transparent">
    <q-toolbar>
      <svg
        width="60px"
        height="18px"
        viewBox="0 0 82 26"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
      >
        <title>画板</title>
        <g
          id="画板"
          stroke="none"
          stroke-width="1"
          fill="none"
          fill-rule="evenodd"
        >
          <g id="logo-顶导">
            <rect
              id="矩形"
              fill="#D8D8D8"
              opacity="0"
              x="0"
              y="0"
              width="82"
              height="26"
            ></rect>
            <path
              d="M40.730699,25.553536 C40.730699,25.6709712 40.8335468,25.7660629 40.9604205,25.7660629 L46.4314792,25.7660629 C46.5583529,25.7660629 46.6612007,25.6709712 46.6612007,25.553536 L46.6612007,0.922970695 C46.6612007,0.805535552 46.5583529,0.710337902 46.4314792,0.710337902 L40.9604205,0.710337902 C40.8335468,0.710337902 40.730699,0.805535552 40.730699,0.922970695 L40.730699,25.553536 Z M0.508790868,25.553536 C0.508790868,25.6709712 0.611638638,25.7660629 0.738512321,25.7660629 L6.20957109,25.7660629 C6.33644478,25.7660629 6.43929255,25.6709712 6.43929255,25.553536 L6.43929255,10.0477555 C6.43929255,9.93032033 6.33644478,9.83522857 6.20957109,9.83522857 L0.738512321,9.83522857 C0.611638638,9.83522857 0.508790868,9.93032033 0.508790868,10.0477555 L0.508790868,25.553536 Z M24.3947744,20.3676149 C20.4314471,21.0880038 16.6121699,18.3688878 15.8809602,14.3064155 C15.1497505,10.2438372 17.7792181,6.35269945 21.7425454,5.63231056 C25.7058728,4.91202756 29.52515,7.63103764 30.2563597,11.6936159 C30.9875694,15.7560882 28.3581018,19.647226 24.3947744,20.3676149 Z M37.1201838,21.5332831 L34.4135803,19.3501966 C34.3577306,19.3051922 34.3213756,19.2433508 34.3074659,19.176956 C34.2934508,19.1104553 34.3017755,19.0394012 34.3353908,18.9758655 C35.6298395,16.5317532 36.1463967,13.6516801 35.6185642,10.7189783 C34.3684791,3.7734679 27.7362732,-0.835729119 20.8051133,0.424077827 C13.8739534,1.68377888 9.26867052,8.33554261 10.5187557,15.281053 C11.7688408,22.2264576 18.4010467,26.8356546 25.3322066,25.5759535 C27.259127,25.2256601 29.0057477,24.458043 30.4972511,23.3837603 C30.6074752,23.3044465 30.7560565,23.3068821 30.8617495,23.3921258 L33.7649861,25.7338397 C33.863408,25.8132594 34.0091441,25.7951517 34.0903897,25.6933887 L37.15127,21.8613391 C37.2325155,21.7595761 37.2186057,21.6127027 37.1201838,21.5332831 Z M81.7702785,0.710390848 L76.2992198,0.710390848 C76.1723461,0.710390848 76.0694983,0.805588498 76.0694983,0.922917749 L76.0694983,25.553589 C76.0694983,25.6709182 76.1723461,25.7661159 76.2992198,25.7661159 L81.7702785,25.7661159 C81.8971522,25.7661159 82,25.6709182 82,25.553589 L82,0.922917749 C82,0.805588498 81.8971522,0.710390848 81.7702785,0.710390848 Z M3.47406278,0.219238745 C1.55536177,0.219238745 0,1.78221685 0,3.71031342 C0,5.63840998 1.55536177,7.20138809 3.47406278,7.20138809 C5.3927638,7.20138809 6.94812556,5.63840998 6.94812556,3.71031342 C6.94812556,1.78221685 5.3927638,0.219238745 3.47406278,0.219238745 Z M73.1731639,0.710390848 L67.3432971,0.710390848 C67.242873,0.710390848 67.1504575,0.761642976 67.1032487,0.843815808 L61.6862482,10.5227377 C61.6862482,10.5227377 61.656639,10.5774628 61.6129513,10.5921373 L61.5934113,10.5956979 C61.5528675,10.594586 61.5209779,10.5541019 61.507567,10.5339293 L61.5006797,10.5227377 L61.5006797,10.5227377 L56.0836792,0.843815808 C56.0364704,0.761642976 55.9440549,0.710390848 55.8435255,0.710390848 L50.013764,0.710390848 C49.8578063,0.710390848 49.6786657,0.871877407 49.8068039,1.11288948 L58.4715178,15.7632678 C58.5544494,15.9047406 58.5981807,16.0659095 58.5981807,16.2301492 L58.5981807,25.51102 C58.5981807,25.6518575 58.7117769,25.7661159 58.8520335,25.7661159 L64.3348945,25.7661159 C64.4750456,25.7661159 64.5887472,25.6518575 64.5887472,25.51102 L64.5887472,16.2301492 C64.5887472,16.0659095 64.6324786,15.9047406 64.7154101,15.7632678 L73.380124,1.11288948 C73.5081568,0.871877407 73.3290162,0.710390848 73.1731639,0.710390848 Z"
              id="形状"
              fill="#00DC5A"
            ></path>
          </g>
        </g>
      </svg>

      <q-space />
      <q-btn flat round dense icon="search" class="q-mr-xs" />
      <q-btn flat round dense icon="account_circle" />
    </q-toolbar>
  </q-header>

  <q-page v-if="data" class="mt-[-50px]">
    <swiper
      :slides-per-view="1"
      :space-between="0"
      :modules="modules"
      :autoplay="{
        delay: 5000,
        disableOnInteraction: false,
      }"
      :pagination="{
        clickable: true,
      }"
      class="swiper-hot"
    >
      <swiper-slide v-for="(item, index) in data.carousel" :key="index">
        <q-img :ratio="aspectRatio" :src="item.image" />
        <div class="drop-left"></div>
        <div class="drop-center"></div>
        <div class="drop-right"></div>
        <div class="info">
          <div class="flex line-clamp-2 items-center">
            <span class="focus-item-quality">{{ item.quality }}</span>
            <div class="text-weight-medium">{{ item.name }}</div>
          </div>
          <div class="focus-item-info">
            <span class="focus-item-score">
              <Star />
              {{ item.rate }}
            </span>
            <span class="focus-item-year">{{ item.year }}</span>
            <span class="focus-item-update">
              <template v-if="item.process[0] === item.process[1]">
                {{ item.process[0] }} tập
              </template>
              <template v-else>
                Tập {{ item.process[0] }} / {{ item.process[1] ?? "??" }}
              </template>
            </span>
          </div>
          <div class="focus-item-tags" v-if="item.genre.length > 0">
            <span v-for="item in item.genre" :key="item">{{ item }}</span>
          </div>
          <div class="focus-item-desc">
            {{ item.description }}
          </div>
        </div>
      </swiper-slide>
    </swiper>

    <div class="px-4">
      <swiper :slides-per-view="'auto'">
        <swiper-slide
          v-for="item in data.thisSeason"
          :key="item.name"
          class="!w-auto card-wrap"
        >
          <Card :data="item" />
        </swiper-slide>
      </swiper>
    </div>

    <div class="px-4 mt-4">
      <h2 class="text-h6">Đề xuất</h2>

      <swiper
        :slides-per-view="3"
        :breakpoints="{
          0: {
            slidesPerView: 3.1,
            spaceBetween: 8,
          },
          767: {
            slidesPerView: 4.1,
            spaceBetween: 8,
          },
          1023: {
            slidesPerView: 6.1,
            spaceBetween: 16,
          },
        }"
        :grid="{
          rows: 2,
          fill: 'row',
        }"
        :modules="[Grid]"
      >
        <swiper-slide v-for="item in data.nominate" :key="item.name">
          <Card :data="item" />
        </swiper-slide>
      </swiper>
    </div>

    <div class="px-4 mt-4">
      <h2 class="text-h6">Top</h2>

      <swiper :slides-per-view="'auto'">
        <swiper-slide
          v-for="(item, index) in data.hotUpdate"
          :key="item.name"
          class="!w-auto card-wrap"
        >
          <Card :data="item" :trending="index + 1" />
        </swiper-slide>
      </swiper>
    </div>

    <div class="px-4 mt-4">
      <h2 class="text-h6">Sắp chiếu</h2>

      <swiper :slides-per-view="'auto'">
        <swiper-slide
          v-for="item in data.preRelease"
          :key="item.name"
          class="!w-auto card-wrap"
        >
          {{
            item.countdown
              ? dayjs(item.countdown * 1_000 + Date.now()).format("HH:MM")
              : "Sắp chiếu"
          }}
          <Card :data="item" />
        </swiper-slide>
      </swiper>
    </div>

    <div class="px-4 mt-4">
      <h2 class="text-h6">Mới cập nhật</h2>

      <swiper
        :slides-per-view="3"
        :breakpoints="{
          0: {
            slidesPerView: 3.1,
            spaceBetween: 8,
          },
          767: {
            slidesPerView: 4.1,
            spaceBetween: 8,
          },
          1023: {
            slidesPerView: 6.1,
            spaceBetween: 16,
          },
        }"
        :grid="{
          rows: 2,
          fill: 'row',
        }"
        :modules="[Grid]"
      >
        <swiper-slide v-for="item in data.lastUpdate" :key="item.name">
          <Card :data="item" />
        </swiper-slide>
      </swiper>
    </div>
  </q-page>
</template>

<style lang="scss" scoped>
.card-wrap {
  $offset: 0.1;

  // width: 155.25px !important;
  width: calc((100% - 80px) / #{6 + $offset}) !important;
  margin-right: 16px;

  @media screen and (max-width: 767px) {
    width: calc((100% - 16px) / #{3 + $offset}) !important;
    margin-right: 8px;
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: calc((100% - 48px) / #{4 + $offset}) !important;
  }
}
</style>

<script setup lang="ts">
import { shallowRef } from "vue"
import { Index } from "src/apis/index"
import { useRequest } from "vue-request"
import Star from "components/Star.vue"
import Card from "components/Card.vue"
import dayjs from "dayjs"

import html from "src/apis/__test__/data/index.txt?raw"
// Import Swiper Vue.js components
import { Swiper, SwiperSlide } from "swiper/vue"

import { Pagination, Autoplay, Navigation, Grid } from "swiper"

// Import Swiper styles
import "swiper/css"
import "swiper/css/pagination"
import "swiper/css/autoplay"
import "swiper/css/grid"

const modules = [Pagination, Autoplay]

const aspectRatio = 622 / 350

const { data, loading, error } = useRequest(() => Index(html))
</script>

<style lang="scss" scoped>
.swiper-hot {
  position: relative;
  overflow: hidden;
  margin-bottom: -15.5%;
  cursor: pointer;
  z-index: 0;
  height: 56vw;
  max-height: 1012px;
  @media screen and (max-width: 767px) {
    margin-bottom: 16px;
  }
  @media screen and (max-width: 1023px) and (min-width: 768px) {
    margin-bottom: -8.59%;
  }

  .drop {
    &-left {
      position: absolute;
      left: 0;
      top: 0;
      width: 30%;
      height: 100%;
      background: linear-gradient(
        269deg,
        rgba(20, 30, 51, 0) 1%,
        rgba(20, 30, 51, 0.02) 10%,
        rgba(20, 30, 51, 0.05) 18%,
        rgba(20, 30, 51, 0.12) 25%,
        rgba(20, 30, 51, 0.2) 32%,
        rgba(20, 30, 51, 0.29) 38%,
        rgba(20, 30, 51, 0.39) 44%,
        rgba(20, 30, 51, 0.5) 50%,
        rgba(20, 30, 51, 0.61) 57%,
        rgba(20, 30, 51, 0.71) 63%,
        rgba(20, 30, 51, 0.8) 69%,
        rgba(20, 30, 51, 0.88) 76%,
        rgba(20, 30, 51, 0.95) 83%,
        rgba(20, 30, 51, 0.98) 91%,
        rgb(20, 30, 51) 100%
      );
      z-index: 101;

      @media screen and (max-width: 767px) {
        display: none;
      }
    }
    &-center {
      position: absolute;
      left: 0px;
      top: 0px;
      width: 100%;
      height: 120px;
      opacity: 0.7;
      background-image: linear-gradient(
        179.5deg,
        rgba(17, 19, 25, 0.88) 0%,
        rgba(17, 19, 25, 0.89) 9%,
        rgba(17, 19, 25, 0.85) 17%,
        rgba(17, 19, 25, 0.79) 24%,
        rgba(17, 19, 25, 0.72) 31%,
        rgba(17, 19, 25, 0.64) 37%,
        rgba(17, 19, 25, 0.55) 44%,
        rgba(17, 19, 25, 0.45) 50%,
        rgba(17, 19, 25, 0.35) 56%,
        rgba(17, 19, 25, 0.26) 63%,
        rgba(17, 19, 25, 0.18) 69%,
        rgba(17, 19, 25, 0.11) 76%,
        rgba(17, 19, 25, 0.05) 83%,
        rgba(17, 19, 25, 0.01) 91%,
        rgba(17, 19, 25, 0) 100%
      );
    }
    &-right {
      position: absolute;
      right: 0;
      top: 0;
      width: 15%;
      height: 100%;
      background: linear-gradient(
        90deg,
        rgba(20, 30, 51, 0) 1%,
        rgba(20, 30, 51, 0.02) 10%,
        rgba(20, 30, 51, 0.05) 18%,
        rgba(20, 30, 51, 0.12) 25%,
        rgba(20, 30, 51, 0.2) 32%,
        rgba(20, 30, 51, 0.29) 38%,
        rgba(20, 30, 51, 0.39) 44%,
        rgba(20, 30, 51, 0.5) 50%,
        rgba(20, 30, 51, 0.61) 57%,
        rgba(20, 30, 51, 0.71) 63%,
        rgba(20, 30, 51, 0.8) 69%,
        rgba(20, 30, 51, 0.88) 76%,
        rgba(20, 30, 51, 0.95) 83%,
        rgba(20, 30, 51, 0.98) 91%,
        rgb(20, 30, 51) 100%
      );
      z-index: 101;

      @media screen and (max-width: 1808px) {
        display: none;
      }
    }
  }

  .info {
    position: absolute;
    bottom: 0;
    left: 0;
    z-index: 102;
    color: rgb(255, 255, 255);
    width: 100%;
    padding: 60px 30px calc(32% + 24px + 3.5vw) (30px + 64);
    // padding-top: 0;
    background-image: linear-gradient(
      -180deg,
      rgba(0, 0, 0, 0) 0,
      #000000 100%
    );

    @media screen and (max-width: 1023px) and (min-width: 768px) {
      padding: {
        left: 56px;
        bottom: calc(18% + 16px + 36px);
      }
    }
    @media screen and (max-width: 767px) {
      padding: {
        bottom: 20px;
        left: 15px;
      }
    }

    .focus-item-info {
      font-weight: 500;
      margin-top: 12px;
      display: flex;
      font-size: 12px;
      -webkit-box-align: center;
      align-items: center;
      .focus-item-score {
        font-size: 14px;
        color: rgb(28, 199, 73);
        font-weight: 700;
        svg {
          width: 12px;
          height: 12px;
          margin-right: 4px;
        }
      }
      .focus-item-year,
      .focus-item-update {
        text-shadow: rgb(0 0 0 / 50%) 0px 1px 2px;
      }

      .focus-item-score,
      .focus-item-year {
        display: inline-flex;
        line-height: 17px;
        align-items: center;
        &:after {
          content: "";
          margin: 0px 6px;
          height: 10px;
          width: 2px;
          background: rgba(255, 255, 255, 0.2);
        }
      }
    }
    .focus-item-tags {
      margin-top: 13px;
      font-size: 12px;
      line-height: 16px;
      color: rgb(236, 236, 236);
      font-weight: 500;
      text-shadow: rgb(0 0 0 / 50%) 0px 1px 2px;
      span {
        display: inline-block;
        margin-right: 6px;
        padding: 0px 5px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 2px;
      }
    }
    .focus-item-desc {
      width: 31.25vw;
      min-width: 320px;
      overflow: hidden;
      height: 32px;
      line-height: 16px;
      margin-top: 12px;
      font-size: 14px;
      display: -webkit-box;
      text-overflow: ellipsis;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      text-shadow: rgb(0 0 0 / 50%) 0px 1px 2px;
      font-weight: 400; //500;
      @media screen and (max-width: 1023px) and (min-width: 768px) {
        font-size: 12px;
      }
    }
    .focus-item-quality {
      background-image: linear-gradient(
        90deg,
        rgb(0, 214, 57) 0%,
        rgb(0, 194, 52) 100%
      );
      border-radius: 2px 0px 0px 2px;
      padding: 0px 4px;
      margin-right: 4px;
      height: 18px;
      line-height: 18px;
    }
  }
}
</style>
