import enUS from "./en-US";

export default {
  "en-US": enUS
};
